package junit.test;

import org.junit.Test;

import cn.itcast.dao.StudentDao;
import cn.itcast.domain.Student;
import cn.itcast.exception.StudentNotExistException;

public class StudentDaoTest {
	@Test
	public void testadd() {
		StudentDao dao = new StudentDao();
		Student s = new Student();
		s.setExamid("121");
		s.setGrade(89);
		s.setIdcard("121");
		s.setLoccation("����");
		s.setName("����");
		dao.add(s);
	}
	@Test
	public void testFind(){
		StudentDao dao=new StudentDao();
		dao.find("121");
	}
	@Test
	public void testDelete() throws StudentNotExistException{
		StudentDao dao= new StudentDao();
//		dao.delete("sasa");
		dao.delete("����");
	}
}
