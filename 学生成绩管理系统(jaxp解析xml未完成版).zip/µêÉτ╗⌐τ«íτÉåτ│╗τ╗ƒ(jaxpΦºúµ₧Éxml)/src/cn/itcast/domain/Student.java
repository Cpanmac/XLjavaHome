package cn.itcast.domain;

public class Student {
	private String idcard;
	private String examid; // ����
	private String name; // ����
	private String loccation; // ���ڵ�
	private double grade;

	public String getExamid() {
		return examid;
	}

	public String getIdcard() {
		return idcard;
	}

	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}

	public void setExamid(String examid) {
		this.examid = examid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLoccation() {
		return loccation;
	}

	public void setLoccation(String loccation) {
		this.loccation = loccation;
	}

	public double getGrade() {
		return grade;
	}

	public void setGrade(double grade) {
		this.grade = grade;
	}
}
