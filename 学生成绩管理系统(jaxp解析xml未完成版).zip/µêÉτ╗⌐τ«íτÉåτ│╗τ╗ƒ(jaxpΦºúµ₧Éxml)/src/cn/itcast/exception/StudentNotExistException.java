package cn.itcast.exception;

public class StudentNotExistException extends Exception {

	public StudentNotExistException() {
		// TODO Auto-generated constructor stub
	}

	public StudentNotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentNotExistException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public StudentNotExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
