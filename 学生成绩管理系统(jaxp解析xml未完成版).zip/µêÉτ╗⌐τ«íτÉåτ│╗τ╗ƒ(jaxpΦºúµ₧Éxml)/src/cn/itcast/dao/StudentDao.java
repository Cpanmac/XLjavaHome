package cn.itcast.dao;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import cn.itcast.domain.Student;
import cn.itcast.exception.StudentNotExistException;
import cn.itcast.utils.*;

//�ѿ����������ݿ�
public class StudentDao {
	public void add(Student s) {
		try {
			// ����ʱ�쳣,Ҫת�������쳣
			Document document = XmlUtils.getDocument();
			// ��������װѧ����Ϣ�ı�ǩ
			Element student_tag = document.createElement("student");
			student_tag.setAttribute("idcard", s.getIdcard());
			student_tag.setAttribute("examid", s.getExamid());
			// �������ڷ�װѧ������,���ڵغͳɼ���ǩ
			Element name = document.createElement("name");
			Element location = document.createElement("location");
			Element grade = document.createElement("grade");
			name.setTextContent(s.getName());
			location.setTextContent(s.getLoccation());
			// ��Ϊgrade��double���͵�����,��+""�������ַ���!
			grade.setTextContent(s.getGrade() + "");
			student_tag.appendChild(name);
			student_tag.appendChild(location);
			student_tag.appendChild(grade);
			XmlUtils.write2Xml(document);
			// �ѷ�װ����Ϣѧ���ı�ǩ�ҵ��ĵ���
			document.getElementsByTagName("exam").item(0).appendChild(
					student_tag);
			XmlUtils.write2Xml(document);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			throw new RuntimeException(e);
		}

	}

	public Student find(String examid) {
		try {
			Document document = XmlUtils.getDocument();
			NodeList list = document.getElementsByTagName("student");
			for (int i = 0; i < list.getLength(); i++) {
				Element student_tag = (Element) list.item(i);
				if (student_tag.getAttribute("examid").equals(examid)) {
					// �ҵ���examidƥ���ѧ��
					Student s = new Student();
					s.setExamid(examid);
					s.setIdcard(student_tag.getAttribute("idcard"));
					// ͨ��student_tag��
					String name = student_tag.getElementsByTagName("name")
							.item(0).getTextContent();
					s.setName(name);
					Double grade = Double.parseDouble(student_tag
							.getElementsByTagName("grade").item(0)
							.getTextContent());
					s.setGrade(grade);
					return s;
				}
			}
			// �������ͨ���ж��Ƿ�Ϊ���ҵ�û��
			return null;

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	// ���ı�ǰ����Ҫ�����û�û���޸ĳɹ���Ҫ���쳣
	public void delete(String name) throws StudentNotExistException {
		try {
			Document document = XmlUtils.getDocument();
			// ���name��ǩ�ļ���
			NodeList list = document.getElementsByTagName("name");
			for (int i = 0; i < list.getLength(); i++) {
				if (list.item(i).getTextContent().equals(name)) {
					list.item(i).getParentNode().getParentNode().removeChild(
							list.item(i).getParentNode());
				
				} else {
					throw new StudentNotExistException(name + "������!!");
				}

			}
			XmlUtils.write2Xml(document);
		} catch (ParserConfigurationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();

		} catch (StudentNotExistException e) {
			// TODO Auto-generated catch block
			throw e;
		} catch (TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
